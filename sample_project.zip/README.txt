Life Singularity - Sample Work
Prepared by: Pravallika [Your Last Name]
Purpose: Small proof-of-concept demonstrating basic FHIR parsing and data processing in Python. 
         Intended to show initiative and ability to work with clinical (FHIR) data and data pipelines relevant to Microsoft Fabric.

Files included:
1) sample_patient.json
   - A sample FHIR Patient resource (JSON).
2) fhir_patient_parser.py
   - Python script that loads `sample_patient.json` and prints key patient fields.
   - Run: python fhir_patient_parser.py
   - Demonstrates: working with FHIR JSON structure in Python, extracting values, basic parsing.
3) sample_patients.csv
   - A small synthetic CSV with patient records (PatientID, Name, Age, Gender).
4) pandas_data_processing.py
   - Python script that loads `sample_patients.csv`, performs simple cleaning, and prints summary statistics.
   - Run: python pandas_data_processing.py
   - Demonstrates: basic data pipeline skills with pandas (cleaning, aggregation, summary stats).

Dependencies:
- Python 3.8 or higher
- pandas (pip install pandas)

How to run:
1) Unzip the archive (if zipped).
2) Install dependencies:
   pip install pandas
3) Run the scripts:
   python fhir_patient_parser.py
   python pandas_data_processing.py

What this demonstrates and talking points:
- Familiarity with FHIR resource formats and how to programmatically extract clinical fields (useful for ingestion into a feature store).
- Basic data transformation skills using pandas (a core skill for building dataflows and ETL tasks relevant to Microsoft Fabric).
- Modular, commented scripts that can be migrated into notebook environments or Fabric notebooks/dataflows.
- Eager to learn: this is an early-stage demonstration; happy to expand or rework per your team's preferences or create a Fabric notebook if desired.

Notes:
- These are intentionally small, self-contained examples so reviewers can run them quickly.
- If you'd like, I can convert these into a single Jupyter Notebook with markdown explanations and inline outputs for easier review.

Thank you for reviewing my sample work. I'm excited about the opportunity to learn and contribute to Life Singularity.

Best regards,
Pravallika [Your Last Name]
